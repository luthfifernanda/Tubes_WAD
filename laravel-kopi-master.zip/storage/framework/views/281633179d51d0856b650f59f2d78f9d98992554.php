<?php $__env->startSection('title'); ?> Pasar <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<div class="container">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Pasar</h1>
        <a href="<?php echo e(route('pasar.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i>Tambah Pasar</a>
    </div>
</div>
<div class="row">
    <div class="card-body">
        <div class="table-responsive">
            <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nama Pasar</th>
                        <th>Alamat</th>
                        <th>Foto</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pasars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pasar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pasar->nama); ?></td>
                        <td><?php echo e($pasar->lokasi); ?> </td>
                        <td><img src="<?php echo e(asset('storage/' . $pasar->gambar)); ?>" width="200px;" height="100px;"></td>
                        <td>

                            <form action="<?php echo e(route('pasar.destroy', [$id = $pasar->id])); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>



                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

</div>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samba\Downloads\laravel-tancab-master\resources\views/admin/pasar/index.blade.php ENDPATH**/ ?>