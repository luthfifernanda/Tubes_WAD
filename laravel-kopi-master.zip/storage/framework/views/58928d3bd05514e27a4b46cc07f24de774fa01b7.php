 <div class="navbar navbar-expand-lg navbar-light home-navbar">
     <div class="container">
         <a class="navbar-brand" href="/">Kopii.id</a>
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
             <div class="navbar-nav ml-auto">

                 <a class="nav-item nav-link" href="<?php echo e(route('pasar.index')); ?>">Pasar</a>
                 <a class="nav-item nav-link" href="<?php echo e(route('project.index')); ?>">Investasi</a>
                 <a class="nav-item nav-link" href="<?php echo e(route('forum.index')); ?>">Forum</a>
                 <a class="nav-item nav-link" href="<?php echo e(route('artikel.index')); ?>">Artikel Kopi</a>
                 <?php if(auth()->guard()->guest()): ?>
                 <a class="nav-item nav-link pull-right" href="<?php echo e(url('login')); ?>">Login</a>
                 <?php endif; ?>

                 <?php if(auth()->guard()->check()): ?>
                 <li class="nav-item dropdown no-arrow">
                     <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         <?php echo e(Auth::user()->name); ?>


                     </a>
                     <!-- Dropdown - User Information -->
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                         <a class="dropdown-item" href="<?php echo e(route('user.show', [$id = Auth::user()->id])); ?>">
                             <span style="color:black;">My Profile</span>
                         </a>


                         <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                             <span style="color:black;"><?php echo e(__('Logout')); ?></span>
                         </a>

                         <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                             <?php echo csrf_field(); ?>
                         </form>
                     </div>


                 </li>

                 <?php endif; ?>
             </div>
         </div>
     </div>
 </div><?php /**PATH C:\xampp\htdocs\laravel-kopi-master\resources\views/includes/navbar.blade.php ENDPATH**/ ?>