<?php $__env->startSection('title'); ?> Artikel <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h2 class="text-center pt-4 text-muted">ARTIKEL CABAI</h2>


<div class="container">
    <div class="artikel">
        <div class="row pt-3">
            <div class="col-5">
                <h5 style="color:black; margin-left: 10px;">Terkini</h5>
                <a href="<?php echo e(route('artikel.show', [$id = $terkini->id])); ?>" style="color:white;">
                    <div class="artikel-foto" style="background-image: linear-gradient(to bottom, rgba(245, 246, 252, 0.0), rgba(0, 0, 0, 1)), url('<?php echo e(asset('storage/'.$terkini->gambar)); ?>');">
                        <h5 style="font-size: 18px; padding-top: 220px;" class="text-center"><?php echo e($terkini->judul); ?></h5>
                        <img src="<?php echo e(asset('storage/' . $terkini->user->avatar)); ?>" alt="" class="rounded-circle mt-4" width="25px;" height="25px;" style="margin-left: 25px; float: left;">
                        <p style="margin-top: 33px; margin-left: 56px;"><?php echo e($terkini->user->name); ?></p>
                        <small style="margin-left:50px;">Dibuat <?php echo e($terkini->created_at->diffForHumans()); ?></small>
                    </div>
                </a>
            </div>


            <div class="col offset-1 mt-3">
                <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset('storage/'.$artikel->gambar)); ?>" alt="" style="float:left; margin-right: 10px;" height="100px;" width="200px;">
                <a href="<?php echo e(route('artikel.show', [$id = $artikel->id])); ?>">
                    <h5 style="color:black; font-weight: bold;"><?php echo e($artikel->judul); ?></h5>
                </a>
                <small style="color:black; "><?php echo e($artikel->deskripsi); ?></small>
                <div class="zs" style="height: 10px;">

                </div>
                <hr style=" border: 0;
                    padding-top: 3px;
                                        clear:both;
                                        display:block;
                                        width: 100%;
                                        background-color:grey;
                                        height: 1px;">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samba\Downloads\laravel-tancab-master\resources\views/artikel/index.blade.php ENDPATH**/ ?>