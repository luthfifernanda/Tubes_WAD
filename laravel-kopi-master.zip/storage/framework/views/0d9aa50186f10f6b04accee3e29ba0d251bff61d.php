<?php $__env->startSection('title'); ?> test <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row pt-5">
        <div class="col-8">
            <div class="card main-card">
                <div class="card-body">
                    <div class="card mt-2 shadow">
                        <!-- buat postingan -->
                        <div class="card" style="background-color: #17D885; height: 30px;">
                            <div class="card-body" style="color:white; margin-top: -16px;">
                                <h5 style="font-weight: bold; font-size: 18px;">Buat Postingan</h5>
                            </div>
                        </div>

                        <!-- buat postingan #2 -->
                        <div class="card-body" style="background-color:#f3f3f3;">
                            <img src="<?php echo e(asset('storage/'.Auth::user()->avatar)); ?>" alt="" class="rounded-circle mt-4" width="79px;" height="79px;" style="margin-top:-24px; float:left;">

                            <form action="<?php echo e(route('forum.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <textarea name="status" id="" cols="50" rows="10" style="margin-top:40px; margin-left: 20px;border: 0; border-radius:20px;" placeholder="  Mulai dengan kata 'hai'..."></textarea>
                                <button class="btn btn-kirim" type="submit">Kirim</button>
                            </form>
                        </div>

                    </div>


                    <hr class=" text-muted" style="padding-top: 2px;
                          border: 0;
                          clear:both;
                          display:block;
                          width: 100%;               
                          background-color:#e3e3e3;
                          height: 1px;">

                    <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="other-post" style="margin-left: 10px;">
                        <div class="post pt-3">

                            <img src="<?php echo e(asset('storage/'.$forum->user->avatar)); ?>" alt="" class="rounded-circle mt-4" width="90px;" height="90px;" style="margin-top:-24px; float:left; margin-right: 24px; background-color:black;">

                            <div class="tulisan" style="padding-top:20px;">
                                <small style="color:black; margin-left:460px;"><?php echo e($forum->created_at->diffForHumans()); ?></small>
                                <h5 style="font-weight: bold; color: #707070; "><?php echo e($forum->user->name); ?></h5>
                                <a href="<?php echo e(route('forum.show', [$id = $forum->id])); ?>" style="text-decoration:none; color:#6e6e6e;">
                                    <p><?php echo e($forum->status); ?>

                                    </p>
                                </a>


                                <a href="<?php echo e(action('ForumController@like', ['id' => $forum->id  ])); ?>" style="margin-left:460px; text-decoration: none; color:#707070;"><i class="fas fa-thumbs-up" style="margin-right:5px;"></i>Like</a>
                                <a href="<?php echo e(route('forum.show', [$id = $forum->id])); ?>" style="margin-left: 25px; text-decoration: none; color:#707070;"><i class="fas fa-comments" style="margin-right: 5px;"></i>Komentari</a>
                                <hr>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="card" style="background-color: #F5F4F4; height: 30px;">
                        <div class="card-body" style="color:white; margin-top: -16px;">
                            <h5 style="font-weight: bold; font-size: 18px; color: #707070;">Direkomendasikan</h5>
                        </div>
                    </div>

                    <!-- rekomendasi -->
                    <?php $__currentLoopData = $rekomendasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mt-3">
                        <div class="card-body">
                            <a href="<?php echo e(route('forum.show', [$id = $r->id])); ?>" style="text-decoration:none; color:#6e6e6e;" <p style="color:#707070;"><?php echo e($r->status); ?></p>
                            </a>

                            <a href="" style="margin-left: 175px; text-decoration: none; color:#acacac;"> <i class="fas fa-thumbs-up"> <?php echo e($r->likes); ?></i></a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samba\Downloads\laravel-tancab-master\resources\views/forum/index.blade.php ENDPATH**/ ?>