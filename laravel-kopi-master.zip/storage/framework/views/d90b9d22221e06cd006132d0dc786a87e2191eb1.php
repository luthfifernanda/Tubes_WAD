<?php $__env->startSection('title'); ?> Profil <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row pt-5">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h4 style="color:#6e6e6e;">Profil Saya</h4>
                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <p class="text-muted" style="font-size:14px;z">Kelola informasi profil Anda</p>
                    <hr>
                    <div class="row">
                        <div class="col">
                            <img src="<?php echo e(asset('storage/'.$user->avatar)); ?>" alt="" width="250px;" height="250px;">
                            <form action="<?php echo e(route('user.update', [$id = $user->id])); ?>" enctype="multipart/form-data" method="post" class="pt-4">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <label for="avatar" style="color:#6e6e6e;">Ubah Foto</label>
                                <input type="file" name="avatar" id="avatar" style="color:#6e6e6e;"><br><br>

                                <p style="color: #6e6e6e;">Saldo anda kosong? isi saldo anda <a href="<?php echo e(route('user.isisaldo', [$id = $user->id])); ?>">disini</a></p>

                        </div>

                        <div class="col">

                            <div class="form-group">
                                <label for="nama" style="color:#6e6e6e;">Nama</label>
                                <input type="text" class="form-control" id="nama" placeholder="nama" value="<?php echo e($user->name); ?>" name="name">
                            </div>

                            <div class="form-group">
                                <label for="email" style="color:#6e6e6e;">Email</label>
                                <input type="email" class="form-control" id="email" placeholder="email" value="<?php echo e($user->email); ?>" disabled>
                            </div>

                            <div class="form-group">
                                <label for="alamat" style="color:#6e6e6e;">Alamat</label>
                                <textarea type="text" class="form-control" id="alamat" placeholder="alamat" name="alamat"><?php echo e($user->alamat); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label for="saldo" style="color:#6e6e6e;">Saldo</label>
                                <input type="number" class="form-control" id="saldo" placeholder="saldo" value="<?php echo e($user->saldo); ?>" disabled>
                            </div>

                            <button class="btn btn-upload" type="submit">Simpan</button>
                        </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-kopi-master\resources\views/user/show.blade.php ENDPATH**/ ?>