<?php $__env->startSection('title'); ?> Proyek <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<div class="container">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Project / Investasi</h1>

    </div>
</div>
<div class="row">
    <div class="card-body">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nama Pengelola</th>
                        <th>Jenis Kopi</th>
                        <th>Gambar</th>
                        <th>Lokasi</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($project->user->name); ?></td>
                        <td><?php echo e($project->jenis_kopi); ?> </td>
                        <td><img src="<?php echo e(asset('storage/' . $project->gambar)); ?>" width="100px;" height="50px;"> </td>
                        <td><?php echo e($project->lokasi); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.project.destroy', [$id = $project->id])); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="7" class="text-center">

                        </td>
                    </tr>

                </tbody>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            <?php echo e($projects->links()); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

</div>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-kopi-master\resources\views/admin/project/index.blade.php ENDPATH**/ ?>