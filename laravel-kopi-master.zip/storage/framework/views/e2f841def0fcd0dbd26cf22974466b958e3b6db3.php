<?php $__env->startSection('title'); ?> Profil <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row pt-5">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h4 style="color:#6e6e6e;" class="text-center">Isi saldo</h4>
                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <hr>
                    <div class="row">

                        <div class="col">
                            <form action="<?php echo e(route('user.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="user_id">
                                <div class="form-group">
                                    <label for="nama" style="color:#6e6e6e;">Nama</label>
                                    <input type="text" class="form-control" id="nama" placeholder="nama" value="<?php echo e($user->name); ?>" name="name" disabled>
                                </div>

                                <div class="form-group">
                                    <label for="email" style="color:#6e6e6e;">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="email" value="<?php echo e($user->email); ?>" disabled>
                                </div>

                                <div class="form-group">
                                    <label for="pembayaran" style="color:#6e6e6e;">Pembayaran melalui</label>
                                    <select class="form-control" id="pembayaran" name="pembayaran">
                                        <option value="Mandiri">Bank Mandiri</option>
                                        <option value="BCA">Bank BCA</option>
                                        <option value="BRI">Bank BRI</option>
                                        <option value="alfamart">Alfamart</option>
                                        <option value="indomart">Indomart</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="saldo" style="color:#6e6e6e;">Jumlah saldo</label>
                                    <input type="number" class="form-control" id="saldo" placeholder="saldo" name="saldo">
                                </div>

                                <button class="btn btn-upload" type="submit">Proses</button>
                        </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
</div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-kopi-master\resources\views/user/create.blade.php ENDPATH**/ ?>