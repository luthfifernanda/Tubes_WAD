<?php $__env->startSection('title'); ?> Artikel <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<div class="container">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Artikel</h1>
        <a href="<?php echo e(route('artikel.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i>Tulis Artikel</a>
    </div>
</div>
<div class="row">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Tanggal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('artikel.show', [$id = $artikel->id])); ?>" style="color:#6e6e6e;"><?php echo e($artikel->judul); ?></a></td>
                        <td><?php echo e($artikel->user->name); ?> </td>
                        <td><?php echo e($artikel->created_at->format('D d-M-Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('artikel.edit', [$id = $artikel->id])); ?>" class="btn btn-info">
                                <i class="fa fa-pencil-alt"></i>
                            </a>
                            <form action="<?php echo e(route('artikel.destroy', [$id = $artikel->id])); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>



                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo e($artikels->links()); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

</div>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samba\Downloads\laravel-tancab-master\resources\views/admin/artikel/index.blade.php ENDPATH**/ ?>