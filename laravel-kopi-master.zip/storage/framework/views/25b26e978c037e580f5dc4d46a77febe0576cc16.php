<?php $__env->startSection('title'); ?> Transaksi <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<div class="container">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Transaksi</h1>

    </div>
</div>
<div class="row">
    <div class="card-body">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID Project</th>
                        <th>Nama Pengelola</th>
                        <th>Nama Investor</th>
                        <th>Saldo ditransfer</th>
                        <th>Dana Terkumpul</th>
                        <th>Dana Target</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($transaksi->project->id); ?></td>

                        <td><?php echo e($transaksi->project->user->name); ?></td>
                        <td><?php echo e($transaksi->user->name); ?></td>
                        <td>Rp<?php echo e($transaksi->nominal_transaksi); ?></td>
                        <td>Rp<?php echo e($transaksi->project->dana_terkumpul); ?></td>
                        <td>Rp<?php echo e($transaksi->project->dana_target); ?></td>

                    </tr>

                    <tr>
                        <td colspan="7" class="text-center">

                        </td>
                    </tr>

                </tbody>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-kopi-master\resources\views/admin/transaksi/index.blade.php ENDPATH**/ ?>