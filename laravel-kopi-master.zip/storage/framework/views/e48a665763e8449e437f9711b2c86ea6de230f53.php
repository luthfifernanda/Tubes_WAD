<?php $__env->startSection('title'); ?> Isi saldo <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Heading -->
<div class="container">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Request Isi Saldo</h1>

    </div>
</div>
<div class="row">
    <div class="card-body">
        <div class="table-responsive">
            <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Jumlah Isi Saldo</th>
                        <th>Pembayaran</th>
                        <th>Tanggal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->user->name); ?></td>
                        <td>Rp<?php echo e($item->saldo); ?> </td>
                        <td><?php echo e($item->pembayaran); ?></td>
                        <td><?php echo e($item->created_at->format('D d-M-Y')); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.isisaldo.update', [$id = $item->id])); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="user_id" value="<?php echo e($item->user->id); ?>">
                                <input type="hidden" name="saldo" value=<?php echo e($item->saldo); ?>>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check"></i>
                                </button>
                            </form>
                        </td>
                    </tr>



                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

</div>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samba\Downloads\laravel-tancab-master\resources\views/admin/isisaldo/index.blade.php ENDPATH**/ ?>