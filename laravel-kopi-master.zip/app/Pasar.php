<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class Pasar extends Model
{
    protected $fillable = ['nama', 'lokasi', 'gambar'];
}
